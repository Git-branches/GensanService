<?php

// Shared hosting has one web root and no way to alias /api to the backend's public folder, so this
// file answers /api/* and lets the real front controller run from where the code lives. Every path
// inside that file resolves from its own location, so vendor/, config/, routes/, and storage/ all
// keep working from htdocs/backend.
require __DIR__ . '/../backend/public/index.php';
