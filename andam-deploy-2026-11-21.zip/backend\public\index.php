<?php

require __DIR__ . '/../vendor/autoload.php';

use App\Logger;
use App\Middleware\Cors;
use App\Response;
use App\Router;
use App\SystemCheck;

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/..');
$dotenv->safeLoad();

$appConfig = require __DIR__ . '/../config/app.php';

date_default_timezone_set($appConfig['timezone']);
error_reporting(E_ALL);
ini_set('display_errors', '0');

// Treat PHP warnings and notices as errors so they are logged and never leak into JSON responses.
set_error_handler(function (int $severity, string $message, string $file, int $line): bool {
    if (!(error_reporting() & $severity)) {
        return false;
    }
    throw new ErrorException($message, 0, $severity, $file, $line);
});

set_exception_handler(function (Throwable $e) use ($appConfig) {
    Logger::error($e);
    Response::error($appConfig['debug'] ? $e->getMessage() : 'Something went wrong on our side. Please try again later.', 500);
});

// Refuse to serve a production install whose settings would leak error details or run as root.
$fatalIssues = SystemCheck::fatalIssues($appConfig);
if ($fatalIssues !== []) {
    Logger::message('ERROR', 'Refusing to start: ' . implode(' ', $fatalIssues));
    Response::error('This site is not configured yet. Please contact the administrator.', 503);
}

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');
// The share pages reuse the built frontend, which has one inline script and style, so those need
// 'unsafe-inline'. JSON responses ignore this header.
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
// Admin and write endpoints must never be reused. Public reads can be cached briefly by the
// browser, the service worker, and a CDN, which matters on mobile data.
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET' && !str_starts_with($path, '/api/admin') && !str_starts_with($path, '/api/maintenance') && $path !== '/api/health') {
    header('Cache-Control: public, max-age=60, stale-while-revalidate=300');
} else {
    header('Cache-Control: no-store');
}
if ($appConfig['env'] === 'production') {
    header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
}

Cors::handle();

$router = new Router();
require __DIR__ . '/../routes/api.php';

// frontend/public/.htaccess serves the sitemap, robots.txt, and crawler share pages at the site
// root by rewriting them to the API. mod_rewrite keeps REQUEST_URI, so the router still sees the
// original address. Point those requests at the routes they were rewritten to.
$uri = $_SERVER['REQUEST_URI'] ?? '/';
if ($path === '/sitemap.xml') {
    $uri = '/api/sitemap.xml';
} elseif ($path === '/robots.txt') {
    $uri = '/api/robots.txt';
} elseif (!str_starts_with($path, '/api') && isset($_GET['path'])) {
    $uri = '/api/share';
}

$router->dispatch($_SERVER['REQUEST_METHOD'], $uri);
