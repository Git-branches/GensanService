<?php

namespace App\Controllers\Admin;

use App\Auth;
use App\Database;
use App\Request;
use App\Response;
use App\Services\ActivityLogger;
use App\Services\Slug;
use App\Validators\Validator;

class AgencyController
{
    private const EDITORS = ['super_admin', 'editor'];
    private const PRESENCE = ['physical_office', 'online_only', 'unconfirmed'];
    private const VERIFICATION_STATUSES = ['verified', 'needs_review', 'unverified', 'outdated'];

    // Logos are re-encoded as small WebP files in the uploads folder, served at /api/uploads like the
    // API. The folder and its URL come from config, because shared hosting keeps the writable folder
    // inside the web root instead of next to the code.
    private const LOGO_FOLDER = 'agencies';
    private const LOGO_MAX_BYTES = 2 * 1024 * 1024;
    private const LOGO_MAX_SOURCE_PIXELS = 4000;
    private const LOGO_SIZE = 256;

    public function index(): void
    {
        Auth::requireAdmin();
        $rows = Database::connection()->query(
            "SELECT a.id, a.name, a.slug, a.acronym, a.description, a.logo_url, a.official_website, a.hotline, a.email, a.facebook_url, a.presence, a.verification_status, a.last_verified_at,
                    a.is_local_government, a.is_active,
                    (SELECT COUNT(*) FROM services s WHERE s.agency_id = a.id) AS service_count,
                    (SELECT COUNT(*) FROM services s WHERE s.agency_id = a.id AND s.status = 'published') AS published_count,
                    (SELECT COUNT(*) FROM offices o WHERE o.agency_id = a.id) AS office_count
             FROM agencies a
             ORDER BY a.is_active DESC, a.name"
        )->fetchAll();

        Response::success($rows);
    }

    public function store(): void
    {
        $admin = Auth::requireAdmin(self::EDITORS);
        $data = $this->validate(Request::json());

        $pdo = Database::connection();
        $pdo->prepare(
            'INSERT INTO agencies (name, slug, acronym, description, official_website, hotline, email, facebook_url, presence, is_local_government, is_active)
             VALUES (:name, :slug, :acronym, :description, :website, :hotline, :email, :facebook, :presence, :local, :active)'
        )->execute($data);
        $id = (int) $pdo->lastInsertId();

        ActivityLogger::log((int) $admin['id'], 'agency.created', 'agency', $id, ['name' => $data['name']]);
        Response::success(['id' => $id], 201);
    }

    public function update(array $params): void
    {
        $admin = Auth::requireAdmin(self::EDITORS);
        $id = (int) $params['id'];
        $this->findOrFail($id);
        $data = $this->validate(Request::json(), $id);

        Database::connection()->prepare(
            'UPDATE agencies SET name = :name, slug = :slug, acronym = :acronym, description = :description,
                    official_website = :website, hotline = :hotline, email = :email, facebook_url = :facebook, presence = :presence,
                    is_local_government = :local, is_active = :active
             WHERE id = :id'
        )->execute($data + ['id' => $id]);

        ActivityLogger::log((int) $admin['id'], 'agency.updated', 'agency', $id, ['name' => $data['name']]);
        Response::success(['id' => $id]);
    }

    /** Separate from editing, because editing an agency must never verify it. */
    public function setVerification(array $params): void
    {
        $admin = Auth::requireAdmin(['super_admin', 'reviewer']);
        $agency = $this->findOrFail((int) $params['id']);
        $body = Request::json();

        $v = new Validator();
        $status = (string) ($body['verification_status'] ?? '');
        if (!in_array($status, self::VERIFICATION_STATUSES, true)) {
            $v->add('verification_status', 'Choose a verification status.');
        }
        $checked = $v->date($body['last_verified_at'] ?? null, 'last_verified_at');
        if ($status === 'verified' && $checked === null) {
            $v->add('last_verified_at', 'Enter the date these details were checked.');
        }
        $v->failIfErrors();

        Database::connection()->prepare('UPDATE agencies SET verification_status = :status, last_verified_at = :checked WHERE id = :id')
            ->execute(['status' => $status, 'checked' => $checked, 'id' => $agency['id']]);

        ActivityLogger::log((int) $admin['id'], 'agency.verification_changed', 'agency', (int) $agency['id'], ['name' => $agency['name'], 'to' => $status]);
        Response::success(['verification_status' => $status, 'last_verified_at' => $checked]);
    }

    public function uploadLogo(array $params): void
    {
        $admin = Auth::requireAdmin(self::EDITORS);

        // Shared hosts sometimes ship PHP without GD. Fail with a clear message instead of a 500.
        if (!function_exists('imagecreatetruecolor')) {
            Response::error('Image uploads are not available on this server.', 503, [
                'logo' => 'This server cannot process images. Contact the administrator.',
            ]);
        }

        $agency = $this->findOrFail((int) $params['id']);
        $image = $this->readUploadedImage($_FILES['logo'] ?? null);

        // Re-encoding drops metadata and anything hidden in the original file.
        $width = imagesx($image);
        $height = imagesy($image);
        $scale = min(1, self::LOGO_SIZE / max($width, $height));
        $newWidth = max(1, (int) round($width * $scale));
        $newHeight = max(1, (int) round($height * $scale));

        $logo = imagecreatetruecolor($newWidth, $newHeight);
        imagealphablending($logo, false);
        imagesavealpha($logo, true);
        imagefill($logo, 0, 0, imagecolorallocatealpha($logo, 0, 0, 0, 127));
        imagecopyresampled($logo, $image, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

        $logoDir = $this->logoDir();
        if (!is_dir($logoDir) && !mkdir($logoDir, 0755, true) && !is_dir($logoDir)) {
            throw new \RuntimeException('Could not create the agency logo folder.');
        }
        $fileName = $agency['slug'] . '-' . bin2hex(random_bytes(4)) . '.' . $this->logoExtension();
        $path = $logoDir . '/' . $fileName;
        // WebP is smaller, but not every shared host builds GD with WebP support. PNG always works.
        $saved = function_exists('imagewebp')
            ? imagewebp($logo, $path, 90)
            : imagepng($logo, $path, 9);
        if (!$saved) {
            throw new \RuntimeException('Could not save the agency logo.');
        }

        $url = $this->logoUrl() . $fileName;
        Database::connection()->prepare('UPDATE agencies SET logo_url = :url WHERE id = :id')
            ->execute(['url' => $url, 'id' => $agency['id']]);
        $this->deleteLogoFile($agency['logo_url']);

        ActivityLogger::log((int) $admin['id'], 'agency.logo_updated', 'agency', (int) $agency['id'], ['name' => $agency['name']]);
        Response::success(['logo_url' => $url]);
    }

    public function removeLogo(array $params): void
    {
        $admin = Auth::requireAdmin(self::EDITORS);
        $agency = $this->findOrFail((int) $params['id']);

        Database::connection()->prepare('UPDATE agencies SET logo_url = NULL WHERE id = :id')->execute(['id' => $agency['id']]);
        $this->deleteLogoFile($agency['logo_url']);

        ActivityLogger::log((int) $admin['id'], 'agency.logo_removed', 'agency', (int) $agency['id'], ['name' => $agency['name']]);
        Response::success(['logo_url' => null]);
    }

    private function readUploadedImage(mixed $file): \GdImage
    {
        $invalid = fn (string $message) => Response::error($message, 422, ['logo' => $message]);

        if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) {
            $invalid('Choose a PNG, JPG, or WebP image to upload.');
        }
        if ($file['size'] > self::LOGO_MAX_BYTES) {
            $invalid('The image must be 2 MB or smaller.');
        }

        // Check the real image type and size before decoding, so oversized images can't exhaust memory.
        $info = @getimagesize($file['tmp_name']);
        if ($info === false || !in_array($info[2], [IMAGETYPE_PNG, IMAGETYPE_JPEG, IMAGETYPE_WEBP], true)) {
            $invalid('Use a PNG, JPG, or WebP image.');
        }
        if ($info[0] > self::LOGO_MAX_SOURCE_PIXELS || $info[1] > self::LOGO_MAX_SOURCE_PIXELS) {
            $invalid('The image must be at most 4000 × 4000 pixels.');
        }

        $image = @imagecreatefromstring((string) file_get_contents($file['tmp_name']));
        if ($image === false) {
            $invalid('This image could not be read. Try saving it as a PNG.');
        }
        return $image;
    }

    /** The file extension this server's GD can actually write. */
    private function logoExtension(): string
    {
        return function_exists('imagewebp') ? 'webp' : 'png';
    }

    private function deleteLogoFile(?string $url): void
    {
        // Only files this controller saved are removed; basename() keeps it inside the logo folder.
        if ($url && str_starts_with($url, $this->logoUrl())) {
            $path = $this->logoDir() . '/' . basename($url);
            if (is_file($path)) {
                unlink($path);
            }
        }
    }

    /** The folder logos are written to, from UPLOADS_DIR. */
    private function logoDir(): string
    {
        $config = require __DIR__ . '/../../../config/app.php';
        return rtrim($config['uploads_dir'], '/\\') . '/' . self::LOGO_FOLDER;
    }

    /** The public address logos are served from, from UPLOADS_URL. */
    private function logoUrl(): string
    {
        $config = require __DIR__ . '/../../../config/app.php';
        return rtrim($config['uploads_url'], '/') . '/' . self::LOGO_FOLDER . '/';
    }

    /** @return array{id: int, name: string, slug: string, logo_url: ?string} */
    private function findOrFail(int $id): array
    {
        $stmt = Database::connection()->prepare('SELECT id, name, slug, logo_url FROM agencies WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $agency = $stmt->fetch();
        if (!$agency) {
            Response::notFound('Agency not found');
        }
        return $agency;
    }

    /** @return array<string, mixed> */
    private function validate(array $body, ?int $id = null): array
    {
        $v = new Validator();
        $pdo = Database::connection();

        $name = $v->string($body['name'] ?? null, 'name', 150, true, 2);
        $v->string($body['slug'] ?? null, 'slug', 160);
        $data = [
            'name' => $name,
            'slug' => Slug::unique($pdo, 'agencies', $body['slug'] ?? null, (string) $name, $id, $v),
            'acronym' => $v->string($body['acronym'] ?? null, 'acronym', 20),
            'description' => $v->string($body['description'] ?? null, 'description', 2000),
            'website' => $v->optionalUrl($body['official_website'] ?? null, 'official_website'),
            'hotline' => $v->string($body['hotline'] ?? null, 'hotline', 100),
            'email' => $v->email($body['email'] ?? null, 'email'),
            'facebook' => $v->optionalUrl($body['facebook_url'] ?? null, 'facebook_url'),
            'presence' => in_array($body['presence'] ?? null, self::PRESENCE, true) ? $body['presence'] : 'unconfirmed',
            'local' => $v->bool($body['is_local_government'] ?? false),
            'active' => $v->bool($body['is_active'] ?? true),
        ];

        // Deactivating an agency would break the agency links on its live guides.
        if ($id !== null && $data['active'] === 0) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM services WHERE agency_id = :id AND status = 'published'");
            $stmt->execute(['id' => $id]);
            $published = (int) $stmt->fetchColumn();
            if ($published > 0) {
                $v->add('is_active', "Unpublish or archive this agency's {$published} published guide(s) first.");
            }
        }

        $v->failIfErrors();
        return $data;
    }
}
